const button = document.getElementById('button');
const titolo = document.getElementById('titolo');
const autore = document.getElementById('autore');
const pagine = document.getElementById('pagine');
const anno = document.getElementById('anno');

let datiLibro;

button.addEventListener('click', function () {
    datiLibro = {
        'titolo': titolo.value,
        'autore': autore.value,
        'pagine': pagine.value,
        'anno': anno.value
    }

    // console.log(datiLibro);

    fetch('/sendData', {
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
        body: JSON.stringify(datiLibro)
    })
        .then(response => response.text())
        .then(data => console.log(`THEN: ${datiLibro}`))
    // .then(response => response.text())
})

