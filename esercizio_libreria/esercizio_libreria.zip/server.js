const express = require('express');
const fs = require('fs');
const app = express();
const port = 3000;

// !!!!IMPORTANTE!!!!
// https://stackoverflow.com/questions/36856232/write-add-data-in-json-file-using-node-js
// https://stackoverflow.com/questions/53054756/javascript-appending-object-to-json-file
// !!!!!!!!!!!!!!!!!!

app.use(express.static('public'));
app.use(express.json());

app.post('/sendData', (req, res) => {
    console.log(req.body)
    // fs.writeFile('libreria.json', JSON.stringify(req.body, null, 2), (error) => {
    //     if (error) {
    //         console.log('An error has occurred ', error);
    //         return;
    //     }
    //     console.log('Data written successfully to disk');
    // });
    // 1. read and write a .json file
    let librojson = fs.readFileSync("libreria.json", "utf-8");
    // 2. transform a json string into a javascript array
    let libro = JSON.parse(librojson);
    // 3. append an object to an array
    const arr = Array.from(libro);
    arr.push(req.body)
    // 4. transform back the array into a json string
    librojson = JSON.stringify(arr);
    // 5. save the json file
    fs.writeFileSync("libreria.json", librojson, "utf-8");

})

app.listen(port, () => console.log(`App listening on port ${port}!`))